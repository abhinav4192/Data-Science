#### BBC Sports articles
Entity marked in the articles are name of person. Each entity is tagged with a pair of square opening and closing brackets. For Eg:

<b>[[</b>Roger Federer<b>]]</b>

<b>[[</b>Serena Williams<b>]]</b>
